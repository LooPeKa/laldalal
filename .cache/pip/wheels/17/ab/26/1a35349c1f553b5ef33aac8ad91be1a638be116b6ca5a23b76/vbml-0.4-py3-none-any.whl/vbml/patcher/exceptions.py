class VBMLError(RuntimeError):
    pass


class PatternError(VBMLError):
    pass


class LoaderError(VBMLError):
    pass

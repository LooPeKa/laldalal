See https://github.com/Emberium/SimpleQIWI



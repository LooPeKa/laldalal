#!/usr/bin/env python
# -*- coding: utf-8 -*-


class QIWIAPIError(Exception):
    pass


class ArgumentError(Exception):
    pass


class InvalidTokenError(Exception):
    pass


class OverridingEx(Exception):
    pass
